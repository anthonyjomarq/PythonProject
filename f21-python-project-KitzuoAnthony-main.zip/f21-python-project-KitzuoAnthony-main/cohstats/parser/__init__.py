# DON'T CHANGE ANYTHING IN THIS FILE
from .parser import *

print('loading cohstats.parser module __init__.py script')

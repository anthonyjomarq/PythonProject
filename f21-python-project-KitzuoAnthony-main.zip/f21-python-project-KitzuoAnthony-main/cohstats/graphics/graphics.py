import turtle
# initializes turtle graphics coordinates
new_x_position = 720 / -2
new_y_position = 675 / -2
print('Window height:' + str(new_x_position))
print('Window width:' + str(new_y_position))
turtle.tracer(0, 0)

# draws a text on the screen
def draw_text(the_text, x, y):
    turtle.penup()
    turtle.goto(new_x_position + x, new_y_position + y)
    turtle.pendown()
    turtle.write(the_text, True, align="left", font=("Arial", 20, "normal"))

# draws a bar on the screen
def draw_bar(x, y, height, width, color):
    turtle.pencolor(color)
    turtle.pensize(0)
    turtle.penup()
    turtle.setposition(new_x_position + x, new_y_position + y)
    turtle.pendown()
    turtle.fillcolor(color)
    turtle.begin_fill()

    turtle.forward(width)
    turtle.left(90)
    turtle.forward(height)
    turtle.left(90)
    turtle.forward(width)
    turtle.left(90)
    turtle.forward(height)
    turtle.left(90)
    turtle.end_fill()



def draw_bars(x, y, color, width=10, gap=5,  total_bars=1):
    i = 0
    while i < total_bars :
        draw_text('Click anywhere on the window to close turtle graphics', 10, 10)
        draw_bar(x + (i*(width + gap)), 50, 400, width, color)
        i += 1

def render() :
    turtle.update()  # Render image
    turtle.exitonclick()  # Wait for user's mouse click

# You have to implement the following 4 functions
def get_value_from_tuple(x):
    return x[1]

def plot_top_k_service_types(data, metadata, k):
    x_start = 5
    list_to_graph = sorted(list(data[metadata].items()), key=get_value_from_tuple, reverse=True)[:k]
    for key, value in list_to_graph:
            draw_bar(x_start, 525, value, 50, 'green')
            draw_text(key, x_start + 20, 490)
            draw_text(value, x_start + 55, 525)
            x_start += 100
    draw_text('Displays graph: plot_top_k_service_types', 10, 625)

def plot_bottom_k_service_types (data, metadata, k):
    x_start = 5
    list_to_graph = sorted(list(data[metadata].items()), key=get_value_from_tuple, reverse=True)[k-1::-1]

    for key, value in list_to_graph:
            draw_bar(x_start, 360, value, 50, 'blue')
            draw_text(key, x_start + 20, 325)
            draw_text(value, x_start + 55, 360)
            x_start += 100
    draw_text('Displays graph: plot_bottom_k_service_types', 10, 450)

def plot_service_by_day(data, day):
    count = data['day_of_week'][day]
    draw_bar(5, 200, count, 50, 'red')
    draw_text(day, 25, 165)
    draw_text(count, 60, 200)
    draw_text('Displays graph: plot_service_by_day', 10, 275)

def plot_service_by_hour(data, hour):
    count = data['hour_of_day'][hour]
    draw_bar(5, 50, count, 50, 'purple')
    draw_text(hour, 15, 15)
    draw_text(count, 60, 50)
    draw_text('Displays graph: plot_service_by_hour', 10, 100)

